import pandas as pd
import smtplib
import schedule
import time
import os
from email.message import EmailMessage
from datetime import datetime
import logging
from dotenv import load_dotenv
DRY_RUN = True

# Load environment variables
load_dotenv()

EMAIL = os.getenv("EMAIL")
PASSWORD = os.getenv("PASSWORD")

# Logging setup
logging.basicConfig(filename='logs/email.log', level=logging.INFO)

# Load data
contacts = pd.read_csv('data/contacts.csv')
reminders = pd.read_csv('data/reminders.csv')

# Load template
with open('templates/email_template.txt', 'r') as file:
    template = file.read()

def send_email(to_email, subject, body):
    try:
        # ✅ DRY RUN MODE
        if DRY_RUN:
            print(f"\n[DRY RUN] Email to: {to_email}")
            print(f"Subject: {subject}")
            print(f"Body:\n{body}")
            return "Simulated"

        # ✅ REAL EMAIL MODE
        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = EMAIL
        msg['To'] = to_email
        msg.set_content(body)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(EMAIL, PASSWORD)
            smtp.send_message(msg)

        logging.info(f"SUCCESS: Email sent to {to_email}")
        return "Sent"

    except Exception as e:
        logging.error(f"FAILED: {to_email} - {str(e)}")
        return "Failed"

def process_reminders():
    report = []

    for index, row in reminders.iterrows():
        name = row['name']
        email = row['email']
        subject = row['subject']
        message = row['message']

        personalized = template.format(name=name, message=message)

        status = send_email(email, subject, personalized)

        report.append({
            "name": name,
            "email": email,
            "subject": subject,
            "status": status,
            "time": datetime.now()
        })

    df = pd.DataFrame(report)
    df.to_csv('outputs/report.csv', index=False)

def schedule_jobs():
    for index, row in reminders.iterrows():
        schedule.every(10).seconds.do(process_reminders)

def main():
    print("Scheduler Started...")
    schedule_jobs()

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    main()